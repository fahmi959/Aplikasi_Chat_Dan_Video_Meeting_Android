package com.capstonebangkit.aplikasi_fahmi_chat.FungsiMeeting.Common.Listener

interface ParticipantStreamChangeListener {
    fun onStreamChanged()
}
